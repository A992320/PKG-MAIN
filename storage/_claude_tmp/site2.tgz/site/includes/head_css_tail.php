/* Public language selector */
.site-language-menu{position:relative;flex:0 0 auto;z-index:20}.site-language-menu summary{list-style:none;display:flex;align-items:center;justify-content:center;gap:5px;min-width:48px;height:40px;padding:0 9px;border:1.5px solid rgba(255,255,255,.1);border-radius:20px;background:rgba(255,255,255,.08);color:#ccc;cursor:pointer;transition:background .18s ease,border-color .18s ease,color .18s ease}.site-language-menu summary::-webkit-details-marker{display:none}.site-language-menu summary:hover,.site-language-menu[open] summary{background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.22);color:#fff}.site-language-menu .lcn{display:inline-flex;font-size:.9rem}.site-language-code{font-size:.68rem;font-weight:800;letter-spacing:.04em}.site-language-options{position:absolute;top:calc(100% + 8px);left:0;min-width:132px;padding:6px;border:1px solid rgba(255,255,255,.1);border-radius:9px;background:#171717;box-shadow:0 12px 28px rgba(0,0,0,.38)}.site-language-options a{display:block;padding:8px 10px;border-radius:6px;color:var(--text-muted);font-size:.78rem;font-weight:700;white-space:nowrap;transition:background .16s ease,color .16s ease}.site-language-options a:hover,.site-language-options a.active{background:rgba(255,255,255,.08);color:#fff}.site-language-options a.active::after{content:'✓';float:right;color:var(--red);font-weight:900}@media(max-width:640px){.site-language-menu summary{width:36px;min-width:36px;height:36px;padding:0;border-radius:50%}.site-language-code{display:none}.site-language-options{left:auto;right:0;min-width:122px}}/* Direction-aware language menu */
[dir="rtl"] .site-language-options{right:0;left:auto;text-align:right}[dir="ltr"] .site-language-options{left:0;right:auto;text-align:left}.site-language-options a.active{background:rgba(229,9,20,.14);color:#fff}.site-language-options a.active::after{float:inline-end}@media(max-width:640px){[dir="rtl"] .site-language-options{right:0;left:auto}[dir="ltr"] .site-language-options{left:0;right:auto}}
</style>
<?php if (!empty($custom_css_db)): ?>
<style id="siteCustomTheme"><?php echo strip_tags($custom_css_db); ?>
</style>
<?php endif; ?>
<?php if (($settings['active_theme'] ?? 'default') === 'default'): ?>
<style id="siteVisualPolish">
/* Public visual polish: a restrained, consistent dark surface for every accent color. */
:root{--bg:#0c0e11;--bg2:#12151a;--bg3:#181b21;--surface:#15181d;--border:rgba(255,255,255,.09);--text:#f4f5f7;--text-dim:#c3c7ce;--text-muted:#8b919c;--radius:10px;--radius-lg:14px;--radius-xl:18px;--shadow:0 18px 46px rgba(0,0,0,.42)}
html,body{background:#0c0e11!important;color:var(--text)}
.navbar,.navbar.scrolled,body.shsx-has-hero .navbar:not(.scrolled){background:rgba(12,14,18,.94)!important;border-bottom-color:rgba(255,255,255,.07)!important;box-shadow:0 8px 24px rgba(0,0,0,.22)!important;-webkit-backdrop-filter:blur(18px) saturate(105%)!important;backdrop-filter:blur(18px) saturate(105%)!important}
.search-wrap input{background:#171b23!important;border-color:rgba(255,255,255,.11)!important;box-shadow:none!important}.search-wrap input:focus{background:#1b2029!important;border-color:color-mix(in srgb,var(--accent) 58%,#fff 0%)!important;box-shadow:0 0 0 3px rgba(255,255,255,.05)!important}
.cat-navbar{background:rgba(12,14,18,.9)!important;-webkit-backdrop-filter:blur(14px) saturate(105%)!important;backdrop-filter:blur(14px) saturate(105%)!important}.cat-nav-btn.active{background:var(--red)!important;box-shadow:none!important}
.shsx-bg{filter:blur(14px) saturate(82%) brightness(.38)!important}.shsx-scrim{background:linear-gradient(to left,rgba(8,10,13,.35) 0%,rgba(8,10,13,.72) 48%,rgba(8,10,13,.96) 88%),linear-gradient(to top,#0c0e11 0%,rgba(12,14,17,.62) 36%,rgba(0,0,0,.48) 100%)!important}.shsx-btn-play{box-shadow:none!important}.shsx-btn-info{background:rgba(20,23,28,.82)!important;backdrop-filter:none!important}
.ch-card,.sr-card,.ep-card{background:#15171b!important;box-shadow:0 5px 16px rgba(0,0,0,.24)!important}.ch-card:hover,.sr-card:hover,.ep-card:hover{box-shadow:0 10px 24px rgba(0,0,0,.34)!important}
.site-footer{direction:rtl;background:#101216;border-top:1px solid rgba(255,255,255,.08);color:#eef0f3}.site-footer__inner{max-width:960px;margin:0 auto;padding:44px 28px 36px}.site-footer__brand{text-align:center}.site-footer__name{color:var(--red);font-size:clamp(1.35rem,3vw,1.7rem);font-weight:900;letter-spacing:-.04em;line-height:1.2}.site-footer__rights{margin:9px 0 0;color:#9298a2;font-size:.82rem;line-height:1.7}.site-footer__contact{margin-top:32px}.site-footer__contact-title{display:flex;align-items:center;gap:12px;max-width:320px;margin:0 auto 18px;color:#aeb4be;font-size:.75rem;font-weight:700;letter-spacing:.02em}.site-footer__contact-title span{height:1px;flex:1;background:rgba(255,255,255,.11)}.site-footer__contact-title b{font:inherit;white-space:nowrap}.site-footer__socials{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px}.site-footer__social{display:inline-flex;align-items:center;justify-content:center;gap:9px;min-width:138px;min-height:42px;padding:0 16px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:rgba(29,33,40,.66);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 8px 20px rgba(0,0,0,.16);-webkit-backdrop-filter:blur(14px) saturate(120%);backdrop-filter:blur(14px) saturate(120%);color:#e7e9ed;font-size:.83rem;font-weight:700;text-decoration:none;transition:background .18s ease,border-color .18s ease,transform .18s ease,box-shadow .18s ease}.site-footer__social-icon{width:18px;height:18px;flex:0 0 18px}.site-footer__social:hover{transform:translateY(-1px);background:rgba(42,47,56,.82);box-shadow:inset 0 1px 0 rgba(255,255,255,.12),0 10px 22px rgba(0,0,0,.24);color:#fff}.site-footer__social:active{transform:translateY(0)}.site-footer__social:focus-visible{outline:2px solid var(--accent);outline-offset:3px}.site-footer__social--whatsapp .site-footer__social-icon{color:#35c96a}.site-footer__social--facebook .site-footer__social-icon{color:#65a3ff}.site-footer__social--email .site-footer__social-icon{color:#ff666e}.site-footer__social--whatsapp:hover{border-color:rgba(53,201,106,.42)}.site-footer__social--facebook:hover{border-color:rgba(101,163,255,.42)}.site-footer__social--email:hover{border-color:rgba(255,102,110,.42)}
@media(max-width:640px){.site-footer__inner{padding:36px 18px 30px}.site-footer__contact{margin-top:26px}.site-footer__socials{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.site-footer__social{min-width:0;padding:0 12px;font-size:.8rem}.site-footer__social--email{grid-column:1/-1;max-width:calc(50% - 5px);justify-self:center;width:100%}.site-footer__rights{font-size:.78rem}.shsx-bg{filter:blur(12px) saturate(78%) brightness(.34)!important}}
/* Shared glass layer: reserved for navigation and utility surfaces, not media cards. */
@supports ((-webkit-backdrop-filter:blur(1px)) or (backdrop-filter:blur(1px))){
  .navbar,.navbar.scrolled,body.shsx-has-hero .navbar:not(.scrolled),.cat-navbar{background:rgba(14,17,22,.74)!important;-webkit-backdrop-filter:blur(18px) saturate(115%)!important;backdrop-filter:blur(18px) saturate(115%)!important}
  .site-language-menu summary,.site-language-options,.shs-catmenu-panel,.fp-panel,.np-panel,.m3u-panel,.ep-panel{background:rgba(21,25,31,.76)!important;-webkit-backdrop-filter:blur(18px) saturate(112%)!important;backdrop-filter:blur(18px) saturate(112%)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.07),0 16px 36px rgba(0,0,0,.3)!important}
  .cat-nav-btn{background:rgba(255,255,255,.055)!important}
}
/* Android/WebKit may skip painting content-visibility:auto images inside horizontal rows. */
.ch-thumb img,.sr-poster img,.ep-thumb-video{content-visibility:visible!important;visibility:visible!important;opacity:1!important;display:block!important}
@media(max-width:768px){.netflix-slider-row{content-visibility:visible!important;contain:layout style!important}.ch-thumb img,.sr-poster img{content-visibility:visible!important}}
@media(max-width:660px){
  .shsx-bg{inset:0!important;filter:saturate(74%) brightness(.48)!important;transform:none!important;background-position:center 14%!important}
  .shsx-scrim{background:linear-gradient(to top,#0c0e11 0%,rgba(12,14,17,.96) 25%,rgba(12,14,17,.62) 49%,rgba(8,10,13,.22) 73%,rgba(0,0,0,.42) 100%)!important}
  .shsx-art{display:block!important;position:absolute!important;z-index:2!important;top:calc(var(--shsx-top,88px) + 18px)!important;left:50%!important;width:clamp(112px,34vw,156px)!important;transform:translateX(-50%)!important;border-color:rgba(255,255,255,.16)!important;box-shadow:0 16px 36px rgba(0,0,0,.52)!important}
  .shsx-copy{position:relative;z-index:3!important}
}
@media(max-width:660px){
  .shsx-hero{min-height:clamp(640px,165vw,720px)!important}
  .shsx-inner{justify-content:flex-start!important;padding:calc(var(--shsx-top,88px) + 12px) 18px 56px!important}
  .shsx-art{top:calc(var(--shsx-top,88px) + 12px)!important;width:clamp(96px,28vw,116px)!important}
  .shsx-copy{margin-top:clamp(180px,44vw,205px)!important}
}

/* Player controls: keep every action within narrow touch screens. */
@media (min-width:769px) and (max-width:1024px){.p-vol-slider-wrap{width:56px!important;opacity:1!important;margin-right:6px!important}}
@media (max-width:768px){
  .p-bottom{padding:18px 12px max(14px,env(safe-area-inset-bottom))!important}
  .p-tools{gap:8px!important;min-width:0!important}
  .p-tools-l,.p-tools-r{gap:6px!important;min-width:0!important}
  .p-time-txt{display:none!important}
  .p-vol-slider-wrap{display:none!important;width:0!important;opacity:0!important;margin:0!important}
  .p-vol-wrap{flex:0 0 auto!important;overflow:visible!important}
}
</style>
<?php endif; ?>
<style id="sitePublicBehavior">
/* Keep responsive fixes active for every public theme. */
.site-footer{direction:rtl;background:#101216;border-top:1px solid rgba(255,255,255,.08);color:#eef0f3}.site-footer__inner{max-width:960px;margin:0 auto;padding:44px 28px 36px}.site-footer__brand{text-align:center}.site-footer__name{color:var(--red,#e50914);font-size:clamp(1.35rem,3vw,1.7rem);font-weight:900;letter-spacing:-.04em;line-height:1.2}.site-footer__rights{margin:9px 0 0;color:#9298a2;font-size:.82rem;line-height:1.7}.site-footer__contact{margin-top:32px}.site-footer__contact-title{display:flex;align-items:center;gap:12px;max-width:320px;margin:0 auto 18px;color:#aeb4be;font-size:.75rem;font-weight:700;letter-spacing:.02em}.site-footer__contact-title span{height:1px;flex:1;background:rgba(255,255,255,.11)}.site-footer__contact-title b{font:inherit;white-space:nowrap}.site-footer__socials{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px}.site-footer__social{display:inline-flex;align-items:center;justify-content:center;gap:9px;min-width:138px;min-height:42px;padding:0 16px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:rgba(29,33,40,.66);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 8px 20px rgba(0,0,0,.16);-webkit-backdrop-filter:blur(14px) saturate(120%);backdrop-filter:blur(14px) saturate(120%);color:#e7e9ed;font-size:.83rem;font-weight:700;text-decoration:none}.site-footer__social-icon{width:18px;height:18px;flex:0 0 18px}.site-footer__social--whatsapp .site-footer__social-icon{color:#35c96a}.site-footer__social--facebook .site-footer__social-icon{color:#65a3ff}.site-footer__social--email .site-footer__social-icon{color:#ff666e}.ch-thumb img,.sr-poster img,.ep-thumb-video{content-visibility:visible!important;visibility:visible!important;opacity:1!important;display:block!important}
@media(max-width:768px){.netflix-slider-row{content-visibility:visible!important;contain:layout style!important}.ch-thumb img,.sr-poster img{content-visibility:visible!important}.site-footer__inner{padding:36px 18px 30px}.site-footer__contact{margin-top:26px}.site-footer__socials{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.site-footer__social{min-width:0;padding:0 12px;font-size:.8rem}.site-footer__social--email{grid-column:1/-1;max-width:calc(50% - 5px);justify-self:center;width:100%}.site-footer__rights{font-size:.78rem}.p-bottom{padding:18px 12px max(14px,env(safe-area-inset-bottom))!important}.p-tools{gap:8px!important;min-width:0!important}.p-tools-l,.p-tools-r{gap:6px!important;min-width:0!important}.p-time-txt{display:none!important}.p-vol-slider-wrap{display:none!important;width:0!important;opacity:0!important;margin:0!important}.p-vol-wrap{flex:0 0 auto!important;overflow:visible!important}}
@media(min-width:769px) and (max-width:1024px){.p-vol-slider-wrap{width:56px!important;opacity:1!important;margin-right:6px!important}}
@media(max-width:660px){.shsx-hero{min-height:clamp(640px,165vw,720px)!important}.shsx-bg{inset:0!important;filter:saturate(74%) brightness(.48)!important;transform:none!important;background-position:center 14%!important}.shsx-scrim{background:linear-gradient(to top,#0c0e11 0%,rgba(12,14,17,.96) 25%,rgba(12,14,17,.62) 49%,rgba(8,10,13,.22) 73%,rgba(0,0,0,.42) 100%)!important}.shsx-inner{justify-content:flex-start!important;padding:calc(var(--shsx-top,88px) + 12px) 18px 56px!important}.shsx-art{display:block!important;position:absolute!important;z-index:2!important;top:calc(var(--shsx-top,88px) + 12px)!important;left:50%!important;width:clamp(96px,28vw,116px)!important;transform:translateX(-50%)!important;border-color:rgba(255,255,255,.16)!important;box-shadow:0 16px 36px rgba(0,0,0,.52)!important}.shsx-copy{position:relative;z-index:3!important;margin-top:clamp(180px,44vw,205px)!important}}
</style>
<?php /* كود مخصص يُحقن داخل head (تحليلات/بكسل/سكربت) — من الإعدادات العامة */ ?>
<?php if (!empty($gs_custom_head_code)): ?>
<?php echo $gs_custom_head_code; ?>
<?php endif; ?>
</head>
<body>
<!-- INIT LOADER -->
<div id="nxInitLoader" role="status" aria-label="جارٍ تحميل الموقع">
  <span class="nx-load-indicator" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span>
</div>

